import { createBrowserRouter } from 'react-router-dom'
import { HomePage } from '@/features/home/HomePage'
import { SearchPage } from '@/features/search/SearchPage'
import { AppShell } from './layout/AppShell'
import { NotFoundPage } from './NotFoundPage'
import { PlannedPage } from './PlannedPage'

export const router = createBrowserRouter([
  {
    element: <AppShell />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'search', element: <SearchPage /> },
      { path: 'category/:slug', element: <SearchPage /> },
      { path: 'product/:id', element: <PlannedPage titleKey="pages.product" phase={4} /> },
      { path: 'producer/:id', element: <PlannedPage titleKey="pages.producer" phase={4} /> },
      { path: 'messages', element: <PlannedPage titleKey="pages.messages" phase={5} /> },
      { path: 'messages/:threadId', element: <PlannedPage titleKey="pages.messages" phase={5} /> },
      { path: 'deals', element: <PlannedPage titleKey="pages.deals" phase={6} /> },
      { path: 'deals/:dealId', element: <PlannedPage titleKey="pages.dealDetail" phase={6} /> },
      { path: 'partners', element: <PlannedPage titleKey="pages.partners" phase={6} /> },
      { path: 'dashboard', element: <PlannedPage titleKey="pages.dashboard" phase={7} /> },
      { path: 'settings', element: <PlannedPage titleKey="pages.settings" phase={7} /> },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
])
