import { useId, useState, type ReactElement, type ReactNode } from 'react'
import { cn } from '@/shared/lib/cn'

interface TooltipProps {
  content: ReactNode
  children: ReactElement
  side?: 'top' | 'bottom'
  className?: string
}

/**
 * Lightweight tooltip: shows on hover and keyboard focus, dismisses on Esc, and links
 * its content to the trigger with aria-describedby so screen readers announce it.
 */
export function Tooltip({ content, children, side = 'top', className }: TooltipProps) {
  const id = useId()
  const [open, setOpen] = useState(false)
  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
      aria-describedby={open ? id : undefined}
    >
      {children}
      <span
        id={id}
        role="tooltip"
        className={cn(
          'pointer-events-none absolute start-1/2 z-50 w-max max-w-64 -translate-x-1/2 rounded-md bg-ink px-2.5 py-1.5 text-xs font-normal leading-snug text-bg shadow-pop transition-opacity rtl:translate-x-1/2',
          side === 'top' ? 'bottom-full mb-2' : 'top-full mt-2',
          open ? 'opacity-100' : 'invisible opacity-0',
          className,
        )}
      >
        {content}
      </span>
    </span>
  )
}
