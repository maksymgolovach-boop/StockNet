# Stockyard — B2B producer marketplace (front-end)

React + TypeScript (strict) + Vite + Tailwind v4. No backend: a typed mock database and a promise-based service layer stand in for the API.

## Setup

```bash
npm install
npm run dev        # http://localhost:5173
npm run check      # type-check + locale coverage + mock-data validation + search tests
npm run build      # type-check and production build
```

The demo runs against a fixed date (**16 Oct 2026**, `src/shared/lib/dates.ts`) so expiry badges, document states and deal timelines stay coherent with the mock data.

Fonts (Fraunces + IBM Plex Sans) load from Google Fonts. In sandboxed previews where they are blocked, system fallbacks are used. Storage falls back to memory when `localStorage` is unavailable.

## Folder structure

```
src/
  app/                 App, router, layout (header, mobile nav, footer), shell pages
  config/              Registries — the only place to extend the platform
    categories/        CategoryConfig per root category + tree resolver
    currencies.ts      Currency registry (EUR, USD, RON)
    languages.ts       Language registry (en, de, ro) → locale files
    units.ts           Units, dimensions, imperial equivalents
    certifications.ts  Certifications and standards
  features/            Feature modules (i18n, currency, categories, trust, settings, dev, home, …)
  locales/             en.json, de.json, ro.json
  mocks/               Seeded generators: cities, producers, buyers, catalog templates, deals, reviews, threads
  services/            API layer (mockRequest, catalog, deals, FX) + TanStack Query hooks
  shared/              UI primitives, hooks, libs (geo, storage, random, dates)
  types/models.ts      Domain model
scripts/               check-locales.ts, validate-mocks.ts
```

## Add a category

1. Create a `CategoryConfig` (see `src/config/categories/industrial.ts`): `perishable`, `allowedUnits`, `attributes` (number / enum / boolean / text, each with `filterable`), `certifications`, `logistics`, and the subcategory tree. Subcategories can override logistics (e.g. ready-mix concrete: 45 km / 1.5 h).
2. Append it to `CATEGORY_CONFIGS` in `src/config/categories/index.ts`.
3. Add translation keys to every locale: `categories.<slug>` for each node, `categoryBlurb.<root>`, `attributes.<key>` and `enums.<key>.<option>` for enums with `display: 'translate'`.
4. If the icon is new, register it in `src/features/categories/CategoryIcon.tsx`.

`npm run check:locales` fails if any config-driven key is missing.

## Add a language

1. Add `src/locales/<code>.json` (copy `en.json`; use the plural suffixes `Intl.PluralRules` gives that language).
2. Add one entry to `LANGUAGES` in `src/config/languages.ts` (native name, Intl locale, default currency).

Missing keys fall back to English and log a dev warning.

## Add a currency

Add one entry to `CURRENCIES` in `src/config/currencies.ts` (code, decimals, mock rate from EUR) and its name under `currency.<CODE>` in each locale.

## Replace the mocks with a real API

Each service in `src/services` is an interface plus a mock implementation built on `mockRequest()`. Implement the same interface with `fetch` and swap the export. Query keys and hooks in `services/queries.ts` stay unchanged. FX rates come through the `FxProvider` interface in `fxService.ts`.

## Search

- Matching (`src/features/search/searchIndex.ts`) is diacritic-insensitive and folds ß→ss, ×→x, ²→2 and decimal commas, so "otel" finds "oțel", "Strasse" finds "Straße" and "3x2.5 mm2" finds "3×2,5 mm²".
- Words with digits (specs and standards like `S355`, `C25/30`, `EN 10025`) must match exactly. Other words fall back to fuzzy matching for typos ("rebr" → rebar).
- Filters, facets and sorting are pure functions in `engine.ts`, called by `services/searchService.ts`.
- All search state lives in the URL:

| Param | Meaning |
|---|---|
| `q` | text query |
| `/category/:slug` | category (path) |
| `country`, `cert` | comma lists |
| `radius` | km from your location |
| `pmin`, `pmax`, `punit` | price range in display currency, optional per-unit normalisation |
| `moq`, `rating`, `stock=1`, `delivery=1` | order filters |
| `ver`, `trust`, `partners=1`, `validcerts=1` | trust filters |
| `exp` (`lt7`/`lt30`/`gt30`), `lead` (`immediate`/`lt1w`/`lt1m`/`made_to_order`) | time filters |
| `a.<attribute>` | spec filters: `a.grade=B500C,S355J2`, `a.thicknessMm=2..10`, `a.organic=1` |
| `sort`, `view=grid`, `limit` | sorting, view, page size |

## Map (Booking-style)

- **Desktop:** List view is a split layout (results + sticky map). Map view fills the page with a floating results panel. Grid view hides the map.
- **Mobile:** a floating "Map" button opens a full-screen map with a snapping card carousel. Swiping selects the pin, and tapping a pin scrolls to its card.
- **Pins:** one per producer, labelled with the cheapest matching price in your currency ("€790 / t", "3.900 lei / t"), with "from" and a count when several products match. Pins show states (hover, selected, visited, saved ♥, past partner, verified ✓). Clusters show the count and the lowest price.
- **Sync:** hovering a card highlights its pin (or its cluster), and hovering a pin highlights the cards. Selecting a pin scrolls the list to it and opens a popup card.
- **Area search:** "Search as I move the map", or pan and press "Search this area". The list narrows to the visible bounds (`b=` in the URL) while pins stay visible everywhere. "Reset map" and the "Map area" chip clear it.
- **URL:** `view=map`, `c=lat,lng`, `z=zoom`, `b=south,west,north,east`, `move=1`.
- **Overlays:** your location and the radius filter circle.
- **User-controlled view:** the map fits the results once, then keeps wherever you panned or zoomed, even when filters change. "Reset map" fits everything again.
- **Performance:** icons are memoised by content; hover, selected and visited are CSS classes on the existing element. Leaflet and markercluster load lazily in their own chunk.
- **Accessibility:** pins are focusable buttons with a full label, Enter/Space opens the popup and Esc closes it. The list remains the accessible equivalent of the map.
- **Offline / sandbox:** if OpenStreetMap tiles can't load, a neutral grid and a notice are shown, and pins and interactions keep working.

## Product & producer pages, trust layer

- **Product page** (`/product/:id`): gallery, translatable description, specs from the category config, certifications, a document center, a sticky purchase box with volume price tiers, the seller's trust card, reviews of the product and similar products.
- **Producer page** (`/producer/:id?tab=`): overview, products, trust & documents, reviews, and "Your history". The history tab appears only when you have deals with that producer.
- **Trust score:** click any trust pill to see all seven factors, each with its rule, weight, sub-score, raw value and points. Weights live in `TRUST_WEIGHTS`.
- **Documents:** valid, expiring soon (60 days or less) and expired, with warnings. Downloads are UI-only in this demo.
- **Privacy:** public profiles show only aggregate numbers. Counterparties and amounts appear only to the parties of a deal, and reference customers only when they opted in.
- **Reviews:** only from completed deals. Filter by stars (click a distribution bar), photos or producer reply; sort, mark as helpful, report.
- **Report:** listings, users and reviews, with reason-specific options (demo only, nothing is sent).

## Dev menu

Bottom-left button: switch the demo role (buyer ↔ producer view), simulate API errors (exercises error states), change API latency (exercises skeletons), reset preferences.
