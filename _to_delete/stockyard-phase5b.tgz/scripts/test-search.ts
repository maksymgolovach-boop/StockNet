import { db } from '../src/mocks'
import { ProductSearchIndex, searchCategories, searchProducers } from '../src/features/search/searchIndex'
import { runSearch } from '../src/features/search/engine'
import { emptyFilters } from '../src/features/search/filtersCodec'
import { normalize } from '../src/features/search/normalize'

const idx = new ProductSearchIndex(db.products, db.producers)
const name = (id: string) => db.products.find((p) => p.id === id)!.name
const cases: [string, (names: string[]) => boolean][] = [
  ['S355', (n) => n.length > 0 && n.every((x) => /S355|HEA|profile|Profil|Zuschnitt/i.test(x))],
  ['C25/30', (n) => n.length > 0 && n.every((x) => x.includes('C25/30'))],
  ['3x2.5 mm²', (n) => n.length > 0 && n.every((x) => /3×2[.,]5/.test(x))],
  ['3×2,5 mm²', (n) => n.length > 0 && n.every((x) => /3×2[.,]5/.test(x))],
  ['EN 10025', (n) => n.length >= 3],
  ['otel', (n) => n.some((x) => x.includes('Oțel'))],
  ['Strasse', (n) => n.some((x) => x.includes('Straße'))],
  ['rebr', (n) => n.some((x) => /rebar|Oțel-beton|Betonstahl/i.test(x))],
  ['telemea', (n) => n.some((x) => /telemea/i.test(x))],
  ['kase', (n) => n.some((x) => /Käse/i.test(x))],
  ['cupru', (n) => n.some((x) => /cupru|copper|Kupfer/i.test(x))],
]
let fail = 0
for (const [q, ok] of cases) {
  const res = idx.search(q)!
  const names = [...res].sort((a, b) => a[1] - b[1]).map(([id]) => name(id))
  const pass = ok(names)
  if (!pass) fail++
  console.log(pass ? 'PASS' : 'FAIL', JSON.stringify(q).padEnd(14), String(names.length).padStart(3), '|', names.slice(0, 3).join(' · '))
}
console.log('normalize', normalize('Oțel-beton ȘȚĂÂÎ Straße 3×2,5 mm² m³'))
console.log('categories "beton":', searchCategories('beton'), ' "kabel":', searchCategories('kabel'))
console.log('producers "ruhr":', searchProducers(db.producers, 'ruhr').map((p) => p.name))

const ctx = { location: { lat: 46.7712, lng: 23.6236 }, partnerDeals: { p10: 7, p17: 6 }, rates: { EUR: 1, USD: 1.085, RON: 4.975 }, displayCurrency: 'EUR' }
const f = { ...emptyFilters(), category: 'ready-mix' }
let r = runSearch(db.products, db.producers, null, { filters: f, sort: 'distance', limit: 50 }, ctx)
console.log('ready-mix from Cluj:', r.items.map((i) => `${i.product.name} ${i.distanceKm}km beyond=${i.beyondMaxRange}`))
r = runSearch(db.products, db.producers, null, { filters: { ...emptyFilters(), category: 'metals', attributes: { grade: { kind: 'enum', values: ['B500C'] } } }, sort: 'price_asc', limit: 50 }, ctx)
console.log('metals grade B500C price asc:', r.total, r.items.map((i) => Math.round(i.displayUnitPrice ?? 0)))
r = runSearch(db.products, db.producers, null, { filters: { ...emptyFilters(), pastPartnersOnly: true }, sort: 'relevance', limit: 200 }, ctx)
console.log('past partners only:', r.total, [...new Set(r.items.map((i) => i.producer.id))])
r = runSearch(db.products, db.producers, null, { filters: { ...emptyFilters(), expiry: 'lt7' }, sort: 'expiry', limit: 200 }, ctx)
console.log('expiry <7d:', r.total, '| facets roots:', runSearch(db.products, db.producers, null, { filters: emptyFilters(), sort: 'relevance', limit: 1 }, ctx).facets.categories.map((c) => `${c.value}:${c.count}`).join(' '))
r = runSearch(db.products, db.producers, null, { filters: { ...emptyFilters(), priceMax: 500, priceUnit: 't', category: 'aggregates' }, sort: 'price_asc', limit: 200 }, ctx)
console.log('aggregates ≤500 EUR/t:', r.total)
const all = runSearch(db.products, db.producers, null, { filters: emptyFilters(), sort: 'relevance', limit: 24 }, ctx)
const area = runSearch(db.products, db.producers, null, { filters: emptyFilters(), sort: 'relevance', limit: 24, bounds: { north: 48.3, south: 43.6, east: 29.8, west: 20.2 } }, ctx)
const pinsOk = all.pins.length === db.producers.length && all.pins.every((p) => p.count >= 1) && area.pins.length === all.pins.length && area.total < all.total && area.items.every((i) => i.product.country === 'RO' || i.product.country === 'BG' || i.product.country === 'HU')
console.log(pinsOk ? 'PASS' : 'FAIL', 'pins', all.pins.length, '| Romania bbox list', area.total, 'of', area.unboundedTotal, '| cheapest p10 pin', all.pins.find((p) => p.producerId === 'p10')?.minPrice?.toFixed(2))
if (!pinsOk) fail++
process.exit(fail ? 1 : 0)
