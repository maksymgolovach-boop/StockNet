import { MessagesPage } from '@/features/chat/MessagesPage'
import { createBrowserRouter } from 'react-router-dom'
import { HomePage } from '@/features/home/HomePage'
import { SearchPage } from '@/features/search/SearchPage'
import { ProductPage } from '@/features/product/ProductPage'
import { ProducerPage } from '@/features/producer/ProducerPage'
import { AppShell } from './layout/AppShell'
import { NotFoundPage } from './NotFoundPage'
import { PlannedPage } from './PlannedPage'

export const router = createBrowserRouter([
  {
    element: <AppShell />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'search', element: <SearchPage /> },
      { path: 'category/:slug', element: <SearchPage /> },
      { path: 'product/:id', element: <ProductPage /> },
      { path: 'producer/:id', element: <ProducerPage /> },
      { path: 'messages', element: <MessagesPage /> },
      { path: 'messages/:threadId', element: <MessagesPage /> },
      { path: 'deals', element: <PlannedPage titleKey="pages.deals" phase={6} /> },
      { path: 'deals/new', element: <PlannedPage titleKey="pages.rfq" phase={6} /> },
      { path: 'deals/:dealId', element: <PlannedPage titleKey="pages.dealDetail" phase={6} /> },
      { path: 'partners', element: <PlannedPage titleKey="pages.partners" phase={6} /> },
      { path: 'dashboard', element: <PlannedPage titleKey="pages.dashboard" phase={7} /> },
      { path: 'settings', element: <PlannedPage titleKey="pages.settings" phase={7} /> },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
])
