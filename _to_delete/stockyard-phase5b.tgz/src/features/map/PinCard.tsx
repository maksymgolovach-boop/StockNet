import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Heart, MessageSquare, Star } from 'lucide-react'
import type { MapPin } from '@/features/search/types'
import { getCategoryConfig } from '@/config/categories'
import { Price } from '@/features/currency/Price'
import { useFormat } from '@/features/i18n/useFormat'
import { ProductMedia } from '@/features/product/ProductMedia'
import { AvailabilityBadge, ExpiryBadge } from '@/features/product/StatusBadges'
import { useSaved } from '@/features/saved/savedStore'
import { VerificationBadge } from '@/features/trust/VerificationBadge'
import { buttonClass } from '@/shared/ui/Button'
import { cn } from '@/shared/lib/cn'
import { useMapUi } from './mapUiStore'

/** Compact producer card used in the desktop map popup and the mobile carousel. */
export function PinCard({ pin, className, media = true }: { pin: MapPin; className?: string; media?: boolean }) {
  const { t } = useTranslation()
  const fmt = useFormat()
  const { product: p, producer } = pin.best
  const saved = useSaved((s) => s.producerIds.includes(producer.id))
  const toggleSaved = useSaved((s) => s.toggleProducer)
  const markVisited = useMapUi((s) => s.markVisited)
  const tier = p.pricing.tiers[0]
  const perishable = getCategoryConfig(p.categorySlug)?.perishable

  return (
    <div className={cn('relative flex flex-col bg-surface text-ink', className)}>
      <div className={media ? 'relative' : 'absolute end-2 top-2 z-10'}>
        {media && <ProductMedia media={p.media[0]} categorySlug={p.categorySlug} className="h-24" />}
        <button
          type="button"
          onClick={() => toggleSaved(producer.id)}
          aria-pressed={saved}
          aria-label={t(saved ? 'map.unsave' : 'map.save', { name: producer.name })}
          className={cn('absolute grid size-8 place-items-center', media ? 'start-2 top-2' : 'end-0 top-0', 'rounded-full bg-surface/90 shadow-card hover:bg-surface')}
                  >
          <Heart className={cn('size-4', saved ? 'fill-primary text-primary' : 'text-ink-muted')} aria-hidden />
        </button>
      </div>
      <div className="flex flex-col gap-1.5 p-3">
        <p className={cn('line-clamp-2 text-sm font-semibold leading-snug', !media && 'pe-9')} lang={p.contentLang}>
          {p.name}
        </p>
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="font-medium text-ink-muted">{producer.name}</span>
          <VerificationBadge level={producer.verification} compact />
          {producer.reviewCount > 0 && (
            <span className="inline-flex items-center gap-0.5 text-ink-muted tabular">
              <Star className="size-3 fill-current text-accent" aria-hidden />
              {fmt.number(producer.rating, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {perishable && p.expiryDate ? <ExpiryBadge expiryDate={p.expiryDate} /> : <AvailabilityBadge product={p} />}
          <span className="text-xs text-ink-muted">{fmt.distance(pin.best.distanceKm)}</span>
        </div>
        <div className="flex items-end justify-between gap-2 pt-1">
          <span className="text-base font-semibold">
            {p.pricing.mode === 'on_request' || !tier ? t('common.priceOnRequest') : <Price amount={tier.unitPrice} currency={p.pricing.currency} unit={p.unit} compact={tier.unitPrice >= 100} />}
          </span>
          {pin.count > 1 && <span className="text-xs text-ink-subtle">{t('map.moreProducts', { count: pin.count - 1 })}</span>}
        </div>
        <div className="mt-1 grid grid-cols-2 gap-2">
          <Link to={`/product/${p.id}`} onClick={() => markVisited(producer.id)} className={buttonClass('primary', 'sm')}>
            {t('map.view')}
          </Link>
          <Link to={`/messages?producer=${producer.id}&product=${p.id}`} className={buttonClass('secondary', 'sm')}>
            <MessageSquare className="size-3.5" aria-hidden />
            {t('map.chat')}
          </Link>
        </div>
      </div>
    </div>
  )
}
