import type { CSSProperties } from 'react'
import type { MediaRef } from '@/types/models'
import { getCategoryConfig } from '@/config/categories'
import { CategoryIcon } from '@/features/categories/CategoryIcon'
import { cn } from '@/shared/lib/cn'

/** Neutral placeholder imagery derived from the category icon and the producer's tone. */
export function ProductMedia({ media, categorySlug, className }: { media: MediaRef | undefined; categorySlug: string; className?: string }) {
  const icon = getCategoryConfig(categorySlug)?.icon ?? 'Package'
  return (
    <div aria-hidden style={{ '--h': media?.tone ?? 0 } as CSSProperties} className={cn('product-media relative grid place-items-center overflow-hidden', className)}>
      <CategoryIcon name={icon} className="size-1/3 max-h-14 max-w-14 opacity-70" />
      <span className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/10 to-transparent" />
    </div>
  )
}
