import type { AttributeFilterValue, Filters, GeoBounds, Producer, Product, SortOption } from '@/types/models'
import { getCategoryConfig, getCategoryChildren, getDescendantSlugs, getCategory } from '@/config/categories'
import { convertQuantity, type UnitCode } from '@/config/units'
import { distanceKm, isInBounds, roadDistanceKm } from '@/shared/lib/geo'
import { daysFromNow } from '@/shared/lib/dates'
import { meetsVerification } from '@/features/trust/trustScore'
import { documentStatus, hasValidCertificates } from '@/features/trust/documentStatus'
import type { FacetCount, MapPin, ProducerSummary, SearchContext, SearchResponse, SearchResultItem } from './types'

type FacetKey = 'category' | 'countries' | 'certifications'

function convertPrice(amount: number, from: string, ctx: SearchContext): number {
  const fromRate = ctx.rates[from] ?? 1
  const toRate = ctx.rates[ctx.displayCurrency] ?? 1
  return (amount / fromRate) * toRate
}

function unitPriceIn(item: SearchResultItem, unit: UnitCode | undefined): number | null {
  if (item.displayUnitPrice === null) return null
  if (!unit || unit === item.product.unit) return item.displayUnitPrice
  const productUnitsPerUnit = convertQuantity(1, unit, item.product.unit)
  return productUnitsPerUnit === null ? null : item.displayUnitPrice * productUnitsPerUnit
}

function attributeMatches(product: Product, key: string, filter: AttributeFilterValue): boolean {
  const def = getCategoryConfig(product.categorySlug)?.attributes.find((a) => a.key === key)
  if (!def) return false
  const value = product.attributes[key]
  if (value === undefined) return false
  switch (filter.kind) {
    case 'range':
      return typeof value === 'number' && (filter.min === undefined || value >= filter.min) && (filter.max === undefined || value <= filter.max)
    case 'enum':
      return filter.values.length === 0 || filter.values.includes(String(value))
    case 'boolean':
      return value === filter.value
    case 'text':
      return String(value).toLowerCase().includes(filter.value.toLowerCase())
  }
}

function passes(item: SearchResultItem, f: Filters, producer: Producer, skip?: FacetKey): boolean {
  const p = item.product
  const perishable = getCategoryConfig(p.categorySlug)?.perishable ?? false
  if (skip !== 'category' && f.category && !getDescendantSlugs(f.category).includes(p.categorySlug)) return false
  if (skip !== 'countries' && f.countries.length && !f.countries.includes(p.country)) return false
  if (skip !== 'certifications' && f.certifications.some((c) => !p.certifications.includes(c))) return false
  if (f.radiusKm !== undefined && item.distanceKm > f.radiusKm) return false
  if (f.priceMin !== undefined || f.priceMax !== undefined) {
    const price = unitPriceIn(item, f.priceUnit)
    if (price === null) return false
    if (f.priceMin !== undefined && price < f.priceMin) return false
    if (f.priceMax !== undefined && price > f.priceMax) return false
  }
  if (f.moqMax !== undefined && p.moq > f.moqMax) return false
  if (f.minRating !== undefined && producer.rating < f.minRating) return false
  if (f.inStock && p.availability.status !== 'in_stock') return false
  if (f.deliveryAvailable && (!item.deliversToUser || item.beyondMaxRange)) return false
  if (f.verificationMin && !meetsVerification(producer.verification.level, f.verificationMin)) return false
  if (f.minTrust !== undefined && producer.trust.score < f.minTrust) return false
  if (f.pastPartnersOnly && item.pastPartnerDeals === 0) return false
  if (f.validCertsOnly && (!hasValidCertificates(producer.documents) || p.documents.some((d) => documentStatus(d) === 'expired'))) return false
  if (f.expiry) {
    if (!perishable || !p.expiryDate) return false
    const days = daysFromNow(p.expiryDate)
    if (f.expiry === 'lt7' && days >= 7) return false
    if (f.expiry === 'lt30' && days >= 30) return false
    if (f.expiry === 'gt30' && days <= 30) return false
  }
  if (f.leadTime) {
    if (perishable) return false
    const a = p.availability
    if (f.leadTime === 'immediate' && a.status !== 'in_stock') return false
    if (f.leadTime === 'lt1w' && (a.status === 'made_to_order' || a.leadTimeDays > 7)) return false
    if (f.leadTime === 'lt1m' && a.leadTimeDays > 30) return false
    if (f.leadTime === 'made_to_order' && a.status !== 'made_to_order') return false
  }
  for (const [key, filter] of Object.entries(f.attributes)) if (!attributeMatches(p, key, filter)) return false
  return true
}

const AVAILABILITY_RANK = { in_stock: 0, ships_in: 1, pre_order: 2, made_to_order: 3 } as const

function compare(sort: SortOption, hasQuery: boolean) {
  return (a: SearchResultItem, b: SearchResultItem): number => {
    const nullsLast = (x: number | null, y: number | null, dir: 1 | -1) =>
      x === null && y === null ? 0 : x === null ? 1 : y === null ? -1 : (x - y) * dir
    switch (sort) {
      case 'price_asc':
        return nullsLast(a.displayUnitPrice, b.displayUnitPrice, 1)
      case 'price_desc':
        return nullsLast(a.displayUnitPrice, b.displayUnitPrice, -1)
      case 'distance':
        return a.distanceKm - b.distanceKm
      case 'expiry':
        return nullsLast(a.product.expiryDate ? Date.parse(a.product.expiryDate) : null, b.product.expiryDate ? Date.parse(b.product.expiryDate) : null, 1)
      case 'availability':
        return AVAILABILITY_RANK[a.product.availability.status] - AVAILABILITY_RANK[b.product.availability.status] || a.product.availability.leadTimeDays - b.product.availability.leadTimeDays
      case 'newest':
        return b.product.createdAt.localeCompare(a.product.createdAt)
      case 'rating':
        return b.producer.rating - a.producer.rating || b.producer.reviewCount - a.producer.reviewCount
      case 'trust':
        return b.producer.trustScore - a.producer.trustScore
      case 'relevance': {
        const boost = (i: SearchResultItem) =>
          (hasQuery ? i.score : 0) * 100 - Math.min(i.pastPartnerDeals, 5) * 2 - i.producer.trustScore / 10 + Math.min(i.distanceKm, 1500) / 150
        return boost(a) - boost(b)
      }
    }
  }
}

function count<T>(items: T[], key: (item: T) => string | string[]): FacetCount[] {
  const m = new Map<string, number>()
  for (const item of items) for (const v of [key(item)].flat()) m.set(v, (m.get(v) ?? 0) + 1)
  return [...m].map(([value, c]) => ({ value, count: c })).sort((a, b) => b.count - a.count)
}

export function summarizeProducer(p: Producer): ProducerSummary {
  return {
    id: p.id,
    name: p.name,
    city: p.address.city,
    country: p.address.country,
    verification: p.verification.level,
    trustScore: p.trust.score,
    rating: p.rating,
    reviewCount: p.reviewCount,
    deliveryRadiusKm: p.deliveryRadiusKm,
  }
}

/** One pin per producer with ≥1 match; the label shows the cheapest matching offer. */
export function buildPins(items: SearchResultItem[]): MapPin[] {
  const groups = new Map<string, SearchResultItem[]>()
  for (const item of items) groups.set(item.producer.id, [...(groups.get(item.producer.id) ?? []), item])
  return [...groups.values()].map((group) => {
    const sorted = [...group].sort((a, b) => (a.displayUnitPrice ?? Infinity) - (b.displayUnitPrice ?? Infinity))
    const best = sorted[0] as SearchResultItem
    return {
      producerId: best.producer.id,
      location: best.product.location,
      count: group.length,
      minPrice: best.displayUnitPrice,
      unit: best.product.unit,
      best,
    }
  })
}

export interface RunSearchOptions {
  filters: Filters
  sort: SortOption
  limit: number
  bounds?: GeoBounds
  producerId?: string
  excludeProductId?: string
}

export function runSearch(
  products: Product[],
  producers: Producer[],
  textScores: Map<string, number> | null,
  { filters, sort, limit, bounds, producerId, excludeProductId }: RunSearchOptions,
  ctx: SearchContext,
): SearchResponse {
  const byId = new Map(producers.map((p) => [p.id, p]))
  const candidates: { item: SearchResultItem; producer: Producer }[] = []
  for (const product of products) {
    if ((producerId && product.producerId !== producerId) || product.id === excludeProductId) continue
    const score = textScores ? textScores.get(product.id) : 0
    const producer = byId.get(product.producerId)
    if (score === undefined || !producer) continue
    const distance = distanceKm(ctx.location, product.location)
    const tier = product.pricing.tiers[0]
    const maxKm = product.logistics.timeLimited ? product.logistics.maxDeliveryKm : undefined
    candidates.push({
      producer,
      item: {
        product,
        producer: summarizeProducer(producer),
        distanceKm: Math.round(distance),
        displayUnitPrice: tier ? convertPrice(tier.unitPrice, product.pricing.currency, ctx) : null,
        pastPartnerDeals: ctx.partnerDeals[producer.id] ?? 0,
        deliversToUser: distance <= producer.deliveryRadiusKm,
        beyondMaxRange: maxKm !== undefined && roadDistanceKm(ctx.location, product.location) > maxKm,
        score,
      },
    })
  }
  const matching = candidates.filter((c) => passes(c.item, filters, c.producer)).map((c) => c.item)
  matching.sort(compare(sort, textScores !== null))

  const without = (key: FacetKey) => candidates.filter((c) => passes(c.item, filters, c.producer, key)).map((c) => c.item)
  const parent = filters.category && getCategory(filters.category) ? filters.category : null
  const children = getCategoryChildren(parent)
  const categoryBase = without('category')
  const categories = children
    .map((c) => {
      const slugs = new Set(getDescendantSlugs(c.slug))
      return { value: c.slug, count: categoryBase.filter((i) => slugs.has(i.product.categorySlug)).length }
    })
    .filter((c) => c.count > 0 || parent !== null)

  const listed = bounds ? matching.filter((i) => isInBounds(i.product.location, bounds)) : matching

  return {
    items: listed.slice(0, limit),
    total: listed.length,
    unboundedTotal: matching.length,
    pins: buildPins(matching),
    facets: {
      categories,
      countries: count(without('countries'), (i) => i.product.country),
      certifications: count(without('certifications'), (i) => i.product.certifications),
    },
  }
}
