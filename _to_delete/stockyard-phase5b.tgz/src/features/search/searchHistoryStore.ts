import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { safeStorage } from '@/shared/lib/storage'

interface SearchHistoryState {
  recent: string[]
  add: (query: string) => void
  remove: (query: string) => void
  clear: () => void
}

const MAX = 8

export const useSearchHistory = create<SearchHistoryState>()(
  persist(
    (set) => ({
      recent: ['rebar B500C', 'C25/30', 'NYM-J 3×2,5'],
      add: (query) => {
        const q = query.trim()
        if (q.length < 2) return
        set((s) => ({ recent: [q, ...s.recent.filter((r) => r.toLowerCase() !== q.toLowerCase())].slice(0, MAX) }))
      },
      remove: (query) => set((s) => ({ recent: s.recent.filter((r) => r !== query) })),
      clear: () => set({ recent: [] }),
    }),
    { name: 'sy-search-history', storage: createJSONStorage(() => safeStorage) },
  ),
)
