import type { Buyer, Deal, Message, PartnershipMeta, Producer, Product, Review, Thread } from '@/types/models'
import { getCategory, getCategoryConfig } from '@/config/categories'
import { CURRENCIES } from '@/config/currencies'
import { computeTrustScore } from '@/features/trust/trustScore'
import { validateAttributes } from '@/features/categories/attributeSchema'
import { monthsBetween, now } from '@/shared/lib/dates'
import { createRng } from '@/shared/lib/random'
import { cityById } from './cities'
import { PRODUCER_SEEDS, verificationChecks } from './producers'
import { BUYER_SEEDS, buildBuyer } from './buyers'
import { buildProducts } from './products'
import { buildDeals } from './deals'
import { buildReviews } from './reviews'
import { buildThreads } from './threads'
import { producerDocuments } from './documents'

export { CURRENT_BUYER_ID } from './buyers'
export { CITIES, DEFAULT_CITY_ID, cityById } from './cities'
export type { City } from './cities'

export interface MockDatabase {
  products: Product[]
  producers: Producer[]
  buyers: Buyer[]
  deals: Deal[]
  reviews: Review[]
  threads: Thread[]
  messages: Message[]
  partnershipMeta: PartnershipMeta[]
}

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0)
const round1 = (n: number) => Math.round(n * 10) / 10

function buildDatabase(): MockDatabase {
  const products = buildProducts()
  const byProducer = new Map<string, Product[]>()
  for (const p of products) byProducer.set(p.producerId, [...(byProducer.get(p.producerId) ?? []), p])

  const deals = buildDeals(byProducer)
  const reviews = buildReviews(deals)
  const { threads, messages } = buildThreads(products, deals)
  const rng = createRng(99)

  for (const product of products) {
    const rs = reviews.filter((r) => r.productIds.includes(product.id))
    product.rating = round1(avg(rs.map((r) => r.overall)))
    product.reviewCount = rs.length
  }

  const producers: Producer[] = PRODUCER_SEEDS.map((seed) => {
    const city = cityById(seed.cityId)
    const rs = reviews.filter((r) => r.producerId === seed.id)
    const completed = deals.filter((d) => d.producerId === seed.id && d.status === 'completed')
    const avgRating = rs.length ? round1(avg(rs.map((r) => r.overall))) : 4.2
    const trustInputs = {
      verificationLevel: seed.level,
      onTimeDeliveryRate: seed.onTime,
      avgResponseHours: seed.responseHours,
      disputeRate: seed.disputeRate,
      repeatCustomerRate: seed.repeatRate,
      avgRating,
      accountAgeMonths: monthsBetween(new Date(seed.memberSince), now()),
    }
    const buyerIds = [...new Set(completed.map((d) => d.buyerId))]
    return {
      id: seed.id,
      name: seed.name,
      legalName: seed.legalName,
      type: seed.type,
      address: { street: seed.street, postcode: city.postcode, city: city.name, region: city.region, country: city.country },
      location: { lat: city.point.lat + seed.offset[0], lng: city.point.lng + seed.offset[1] },
      deliveryRadiusKm: seed.deliveryRadiusKm,
      foundedYear: seed.foundedYear,
      memberSince: seed.memberSince,
      employees: seed.employees,
      spokenLanguages: seed.spokenLanguages,
      contentLang: seed.contentLang,
      description: seed.description,
      rootCategories: seed.rootCategories,
      verification: { level: seed.level, checks: verificationChecks(seed) },
      trustInputs,
      trust: computeTrustScore(trustInputs, now().toISOString()),
      documents: producerDocuments(seed, rng),
      publicStats: {
        completedDeals: seed.historicDeals + completed.length,
        repeatCustomerRate: seed.repeatRate,
        yearsActive: now().getFullYear() - seed.foundedYear,
      },
      referenceCustomers: buyerIds.map((buyerId, i) => ({ buyerId, visible: i % 2 === 0 })),
      rating: avgRating,
      reviewCount: rs.length,
      brandHue: seed.brandHue,
    }
  })

  const buyers = BUYER_SEEDS.map((seed) =>
    buildBuyer(seed, 9 + deals.filter((d) => d.buyerId === seed.id && d.status === 'completed').length),
  )

  const partnershipMeta: PartnershipMeta[] = [
    { ownerId: 'b01', counterpartyId: 'p10', favorite: true, tag: 'primary_supplier', privateNotes: 'Framework price for rebar renegotiated each January. Contact: dl. Popescu, logistics.' },
    { ownerId: 'b01', counterpartyId: 'p17', favorite: true, tag: 'local_supplier', privateNotes: 'Pump must be booked 48 h ahead for slabs above 80 m³.' },
    { ownerId: 'b01', counterpartyId: 'p14', favorite: false, tag: 'preferred', privateNotes: 'Ask for drum deposit refund on every 5th order.' },
    { ownerId: 'b01', counterpartyId: 'p22', favorite: false, privateNotes: '' },
    { ownerId: 'b01', counterpartyId: 'p13', favorite: false, tag: 'under_review', privateNotes: 'Weight discrepancy on last delivery — dispute open.' },
  ]

  return { products, producers, buyers, deals, reviews, threads, messages, partnershipMeta }
}

export const db: MockDatabase = buildDatabase()

/** Structural checks of the mock dataset against the category configs and the spec's volume targets. */
export function validateMockData(data: MockDatabase = db): string[] {
  const issues: string[] = []
  for (const p of data.products) {
    const config = getCategoryConfig(p.categorySlug)
    if (!config || !getCategory(p.categorySlug)) {
      issues.push(`${p.id}: unknown category ${p.categorySlug}`)
      continue
    }
    for (const msg of validateAttributes(p.attributes, config)) issues.push(`${p.id} (${p.name}): ${msg}`)
    if (!config.allowedUnits.includes(p.unit)) issues.push(`${p.id}: unit ${p.unit} not allowed in ${config.slug}`)
    for (const c of p.certifications) if (!config.certifications.includes(c)) issues.push(`${p.id}: cert ${c} not in ${config.slug}`)
    if (config.perishable !== (p.expiryDate !== undefined)) issues.push(`${p.id}: expiryDate must exist iff perishable`)
    if (!(p.pricing.currency in CURRENCIES)) issues.push(`${p.id}: bad currency`)
    if (p.pricing.mode !== 'on_request' && p.pricing.tiers.length === 0) issues.push(`${p.id}: priced product without tiers`)
  }
  const countries = new Set(data.producers.map((p) => p.address.country))
  const roots = new Set(data.products.map((p) => p.rootCategorySlug))
  const dealCurrencies = new Set(data.deals.map((d) => d.currency))
  const checks: [boolean, string][] = [
    [data.products.length >= 100, `products ${data.products.length} < 100`],
    [roots.size >= 6, `root categories ${roots.size} < 6`],
    [data.producers.length >= 25, `producers ${data.producers.length} < 25`],
    [countries.size >= 8, `producer countries ${countries.size} < 8`],
    [data.buyers.length === 6, `buyers ${data.buyers.length} != 6`],
    [data.threads.length >= 15, `threads ${data.threads.length} < 15`],
    [data.deals.length >= 30, `deals ${data.deals.length} < 30`],
    [data.reviews.length >= 40, `reviews ${data.reviews.length} < 40`],
    [dealCurrencies.size === 3, `deal currencies ${[...dealCurrencies].join(',')}`],
    [data.reviews.every((r) => data.deals.find((d) => d.id === r.dealId)?.status === 'completed'), 'review without completed deal'],
    [data.deals.every((d) => d.lineItems.length > 0), 'deal without line items'],
  ]
  for (const [ok, msg] of checks) if (!ok) issues.push(msg)
  return issues
}

if (import.meta.env?.DEV) {
  const issues = validateMockData()
  if (issues.length) console.error('[mocks] dataset issues:\n' + issues.join('\n'))
}
