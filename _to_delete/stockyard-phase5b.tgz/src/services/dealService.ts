import type { Deal, Message, PartyRole, Review, Thread } from '@/types/models'
import { db } from '@/mocks'
import { NotFoundError, mockRequest } from './client'

/** Every query is scoped to a party: deal details are only visible to the two parties involved. */
const isParty = (role: PartyRole, partyId: string) => (x: { buyerId: string; producerId: string }) =>
  role === 'buyer' ? x.buyerId === partyId : x.producerId === partyId

export interface ThreadSummary extends Thread {
  lastMessage?: Message
}

export interface DealService {
  deals(role: PartyRole, partyId: string): Promise<Deal[]>
  deal(role: PartyRole, partyId: string, dealId: string): Promise<Deal>
  reviewsForProducer(producerId: string): Promise<Review[]>
  threads(role: PartyRole, partyId: string): Promise<ThreadSummary[]>
  messages(role: PartyRole, partyId: string, threadId: string): Promise<Message[]>
}

export const dealService: DealService = {
  deals: (role, partyId) => mockRequest(() => db.deals.filter(isParty(role, partyId))),
  deal: (role, partyId, dealId) =>
    mockRequest(() => {
      const d = db.deals.find((x) => x.id === dealId && isParty(role, partyId)(x))
      if (!d) throw new NotFoundError(`Deal ${dealId}`)
      return d
    }),
  reviewsForProducer: (producerId) => mockRequest(() => db.reviews.filter((r) => r.producerId === producerId)),
  threads: (role, partyId) =>
    mockRequest(() =>
      db.threads
        .filter(isParty(role, partyId))
        .map((t) => ({ ...t, lastMessage: db.messages.findLast((m) => m.threadId === t.id) }))
        .sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt)),
    ),
  messages: (role, partyId, threadId) =>
    mockRequest(() => {
      const thread = db.threads.find((t) => t.id === threadId && isParty(role, partyId)(t))
      if (!thread) throw new NotFoundError(`Thread ${threadId}`)
      return db.messages.filter((m) => m.threadId === threadId).sort((a, b) => a.sentAt.localeCompare(b.sentAt))
    }),
}
