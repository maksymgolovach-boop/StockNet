import type { PartyRole } from '@/types/models'
import { CURRENCIES, CURRENCY_CODES } from '@/config/currencies'
import { getAllCategories, getDescendantSlugs } from '@/config/categories'
import { db } from '@/mocks'
import { runSearch } from '@/features/search/engine'
import { ProductSearchIndex, searchCategories, searchProducers } from '@/features/search/searchIndex'
import type { SearchContext, SearchParams, SearchResponse, Suggestions } from '@/features/search/types'
import { mockRequest } from './client'

let index: ProductSearchIndex | null = null
const getIndex = () => (index ??= new ProductSearchIndex(db.products, db.producers))

export interface SearchRequestContext {
  location: { lat: number; lng: number }
  displayCurrency: string
  role: PartyRole
  partyId: string
}

function partnerDeals(role: PartyRole, partyId: string): Record<string, number> {
  if (role !== 'buyer') return {}
  const out: Record<string, number> = {}
  for (const d of db.deals) if (d.buyerId === partyId && d.status !== 'cancelled') out[d.producerId] = (out[d.producerId] ?? 0) + 1
  return out
}

export interface SearchService {
  search(params: SearchParams, ctx: SearchRequestContext): Promise<SearchResponse>
  suggest(query: string): Promise<Suggestions>
  partnerDeals(role: PartyRole, partyId: string): Promise<Record<string, number>>
}

/**
 * Mock search endpoint. In production this is a single GET /search with the URL query string;
 * filtering, facet counts and sorting move to the server unchanged in shape.
 */
export const searchService: SearchService = {
  search: (params, req) =>
    mockRequest(() => {
      const ctx: SearchContext = {
        location: req.location,
        displayCurrency: req.displayCurrency,
        partnerDeals: partnerDeals(req.role, req.partyId),
        rates: Object.fromEntries(CURRENCY_CODES.map((c) => [c, CURRENCIES[c].mockRateFromEUR])),
      }
      const scores = getIndex().search(params.filters.q)
      return runSearch(db.products, db.producers, scores, params, ctx)
    }),
  suggest: (query) =>
    mockRequest(
      () => {
        const scores = getIndex().search(query)
        const products = scores
          ? [...scores].sort((a, b) => a[1] - b[1]).slice(0, 5).map(([id]) => db.products.find((p) => p.id === id)).filter((p) => p !== undefined)
          : []
        const counts = (slug: string) => {
          const slugs = new Set(getDescendantSlugs(slug))
          return db.products.filter((p) => slugs.has(p.categorySlug)).length
        }
        const known = new Set(getAllCategories().map((c) => c.slug))
        return {
          products: products.map((p) => ({
            id: p.id,
            name: p.name,
            producerName: db.producers.find((x) => x.id === p.producerId)?.name ?? '',
            categorySlug: p.categorySlug,
          })),
          categories: searchCategories(query)
            .filter((s) => known.has(s))
            .slice(0, 4)
            .map((slug) => ({ slug, productCount: counts(slug) })),
          producers: searchProducers(db.producers, query)
            .slice(0, 3)
            .map((p) => ({ id: p.id, name: p.name, city: p.address.city, country: p.address.country })),
        }
      },
      { latencyFactor: 0.35 },
    ),
  partnerDeals: (role, partyId) => mockRequest(() => partnerDeals(role, partyId), { latencyFactor: 0.3 }),
}
